﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpApplication.EntityModel
{
   public class DepartmentMaster
    {
        public string EmpDepartment { get; set; }
        public string EmpDesignation { get; set; }
     //   public List<DepartmentMaster> emplist { get; set; }
    }
}
