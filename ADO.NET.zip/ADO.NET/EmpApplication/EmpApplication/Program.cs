﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DataAccessLayer;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //EmpMasterDAL empdal = new EmpMasterDAL();
            //EmpMaster emp = new EmpMaster() { EmpCode = 1, EmpName = "SCOTT", EmpDate = Convert.ToDateTime("1980-02-01"), EmpGender = "male", EmpDepartmnet = "sales", EmpDesignation = "manager" };
            //if (empdal.SaveEmployee(emp))
            //{
            //    Console.WriteLine("Employee Information saved");
            //}
            //else
            //{
            //    Console.WriteLine("Error Occured");
            //}

            //DepartmentMaster dep = new DepartmentMaster() { EmpDepartment="Marketing", EmpDesignation="Hr" };
            //DepartmentMasterDal depdal = new DepartmentMasterDal();

            //if (depdal.SaveDepartment(dep))
            //{
            //    Console.WriteLine("Department Information saved");
            //}
            //else
            //{
            //    Console.WriteLine("Error Occured");
            //}

            //EmpMasterDAL empdal = new EmpMasterDAL();
            //EmpMaster emp = new EmpMaster() { EmpCode = 1, EmpName = "Sheila", EmpDate = Convert.ToDateTime("1980-02-01"), EmpGender = "female", EmpDepartmnet = "sales", EmpDesignation = "manager" };
            //if (empdal.UpdateEmployee(emp))
            //{
            //    Console.WriteLine("Employee Information Updated");
            //}
            //else
            //{
            //    Console.WriteLine("Error Occured");
            //}

            //EmpMasterDAL empdal = new EmpMasterDAL();
            //EmpMaster emp = empdal.ViewEmployee(1);
            //if (emp!=null)
            //{
            //    Console.WriteLine($"EmpCode={emp.EmpCode},EmpName={emp.EmpName},EmpDate={emp.EmpDate},EmpDepartmnet={emp.EmpDepartmnet},EmpGender={emp.EmpGender},EmpDesignation={emp.EmpDesignation}");
            //}

            //EmpMaster emp = new EmpMaster();
            //UserInfoDAL user = new UserInfoDAL();
            //bool flag = user.IsValidUser("admin", "admin123");
            //if (flag)
            //{
            //    Console.WriteLine("welcome");
            //}
            //else
            //{
            //    Console.WriteLine("Incorrect Username and password");
            //}
      
            EmpMasterDAL empdal = new EmpMasterDAL();
            //List<EmpMaster> emplist = empdal.ViewAllEmployee();
            //if (emplist.Count>0)
            //{
            //    foreach (EmpMaster item in emplist)
            //    {
            //        Console.WriteLine($"{item.EmpName}\t{item.EmpDate}\t{item.EmpGender}\t{item.EmpDepartmnet}\t{item.EmpDesignation}");
            //    }
            //}
            //else
            //{
            //    Console.WriteLine("No employess found");
            //}


            //SalaryInfoDAL saldal = new SalaryInfoDAL();
            //Console.WriteLine($"no of salrires of {saldal.salaraySheetCount(1)}");

            SalaryInfoDAL saldal = new SalaryInfoDAL();
            //  SalaryInfo sal = new SalaryInfo() {EmpCode=1,DateOfSalary=Convert.ToDateTime("20-10-2016"),Basic=1000000000,Hra=3000,Da=4000 };
            // Console.WriteLine($"{saldal.SaveSalary(sal)}");
            Console.WriteLine($"{saldal.sumOfBasic(1)}");
            Console.ReadLine();

        }
    }
}
