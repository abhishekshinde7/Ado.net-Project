﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using EmpApplication.EntityModel;
using System.Data;

namespace EmpApplication.DataAccessLayer
{
public    class DepartmentMasterDal
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        public bool SaveDepartment(DepartmentMaster empApp)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "insert into DepartmentMaster values('"+empApp.EmpDepartment+"','"+empApp.EmpDesignation+"')";
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch(SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        //public List<DepartmentMaster> PrintDesignations()
        //{
            
        //    try
        //    {
        //        cmd.Connection = sqlcon;
        //        cmd.CommandText = "select distinct(EmpDepartment),EmpDesignation from  DepartmentMaster";
        //       // if()
        //    }
        //    catch (SqlException ex)
        //    {

        //    }
        //    finally
        //    {

        //    }
        //}
    }
}
