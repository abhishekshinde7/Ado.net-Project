﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using EmpApplication.EntityModel;
using System.Data.SqlClient;

namespace EmpApplication.DataAccessLayer
{
 public   class SalaryInfoDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public int salaraySheetCount(int empcode)
        {
            int count = 0;
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select count(*) from SalaryInfo where empcode="+ empcode;
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                count = Convert.ToInt32(cmd.ExecuteScalar());
              
                return count;
            }
            catch (SqlException ex)
            {
                return count;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public int SaveSalary(SalaryInfo sal)
        {
            int no = 0;
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "savesalary";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@empcode", SqlDbType.Int).Value = sal.EmpCode;
                cmd.Parameters.Add("@dateofsalary", SqlDbType.DateTime).Value = sal.DateOfSalary;
                cmd.Parameters.Add("@basic ", SqlDbType.Decimal).Value = sal.Basic;
                cmd.Parameters.Add("@hra ", SqlDbType.Int).Value = sal.Hra;
                cmd.Parameters.Add("@da", SqlDbType.Int).Value = sal.Da;
                cmd.Parameters.Add("@salarysheetno", SqlDbType.Int).Direction = ParameterDirection.Output;
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                no = Convert.ToInt32(cmd.Parameters["@salarysheetno"].Value);
                return no;
            }
            catch (SqlException ex)
            {
                return no;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public double sumOfBasic(int empcode)
        {
            double sum = 0;
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "SumOfSalary";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@empcode", SqlDbType.Int).Value = empcode;
                cmd.Parameters.Add("@sum", SqlDbType.Decimal).Direction = ParameterDirection.Output;

                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }

                cmd.ExecuteNonQuery();
                sum = Convert.ToDouble(cmd.Parameters["@sum"].Value);
                return sum;
            }
            catch(SqlException ex)
            {
                return sum;
            }
            finally
            {
                sqlcon.Close();
            }

        }
    }
}
