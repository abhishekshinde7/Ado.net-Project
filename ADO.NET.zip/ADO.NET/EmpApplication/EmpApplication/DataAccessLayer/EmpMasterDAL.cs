﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using EmpApplication.EntityModel;
using System.Data;

namespace EmpApplication.DataAccessLayer
{
    class EmpMasterDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        public bool SaveEmployee(EmpMaster emp)
        {
            try
            {
                cmd.Connection = sqlcon;
                //cmd.CommandText = "insert into empMaster values(" + emp.EmpCode + ",'" + emp.EmpName + "','"
                //    + emp.EmpDate + "','" + emp.EmpGender + "','" + emp.EmpDepartmnet + "','" + emp.EmpDesignation + "')";
                cmd.CommandText = "SaveEmployee";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EmpCode", SqlDbType.Int).Value = emp.EmpCode;
                cmd.Parameters.Add("@EmpName", SqlDbType.NVarChar).Value = emp.EmpName;
                cmd.Parameters.Add("@EmpDob", SqlDbType.DateTime).Value = emp.EmpDate;
                cmd.Parameters.Add("@EmpGender", SqlDbType.NVarChar).Value = emp.EmpGender;
                cmd.Parameters.Add("@EmpDepartment", SqlDbType.NVarChar).Value = emp.EmpDepartmnet;
                cmd.Parameters.Add("@EmpDesignation", SqlDbType.NVarChar).Value = emp.EmpDesignation;

                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public bool DeleteEmployee(int Empcode)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "delete from Empmaster where empcode=" + Empcode + "";
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public bool UpdateEmployee(EmpMaster emp)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "update Empmaster set EmpName='" + emp.EmpName + "',EmpDob='"
                    + emp.EmpDate + "',EmpGender='" + emp.EmpGender + "',EmpDepartment='" + emp.EmpDepartmnet + "',EmpDesignation='" + emp.EmpDesignation + "' where EmpCode=" + emp.EmpCode;
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public EmpMaster ViewEmployee(int EmpCode)
        {
            EmpMaster emp = new EmpMaster();

            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "Select * From empmaster where empcode=" + EmpCode;
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    emp.EmpCode = Convert.ToInt32(dr["empcode"]);
                    emp.EmpName = dr["empname"].ToString();
                    emp.EmpDate = Convert.ToDateTime(dr["empdob"]);
                    emp.EmpGender = dr["empgender"].ToString();
                    emp.EmpDepartmnet = dr["empdepartment"].ToString();
                    emp.EmpDesignation = dr["empdesignation"].ToString();
                }
                dr.Close();
                return emp;

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Error Occured during Select");
                return emp;
            }
            finally
            {
                sqlcon.Close();
            }


        }

        public List<EmpMaster> ViewAllEmployee()
        {
            List<EmpMaster> emplist = new List<EmpMaster>();
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "Select * from empmaster";
                if (sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        EmpMaster emp = new EmpMaster();
                        emp.EmpCode = Convert.ToInt32(dr["empcode"]);
                        emp.EmpName = dr["empname"].ToString();
                        emp.EmpDate = Convert.ToDateTime(dr["empdob"]);
                        emp.EmpGender = dr["empgender"].ToString();
                        emp.EmpDepartmnet = dr["empdepartment"].ToString();
                        emp.EmpDesignation = dr["empdesignation"].ToString();
                        emplist.Add(emp);
                    }
                }
                dr.Close();
                return emplist;
            }
            catch(SqlException ex)
            {
                return emplist;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public int AutoEmpCode()
        {
            int empcode = 1;
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select Max(empcode) from empmaster";
                if (sqlcon.State==ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                empcode = Convert.ToInt32(cmd.ExecuteScalar());
                empcode++;
                return empcode;
            }
            catch (SqlException ex)
            {
                return 0;
            }
            finally
            {
                sqlcon.Close();
            }
        }
    }
}
